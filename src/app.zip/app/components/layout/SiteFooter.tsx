export function SiteFooter() {
  return (
    <>  
      <hr className="w-full border-gray-400 mb-10" />
      byeeee
    </>
  );
} 